
<?php

$botToken = "6313575381:AAHtBxqyFkUqWw79zx5qTpn6vOLs1KfcXa4";

$id = "5806412095";

?>